####################################################################################################
## Script to run the AFAM App
## This is a simple script to run the AFAM App on your computer
## Please contact Gavin McDonald with any questions - gmcdonald@bren.ucsb.edu
## Originally written at University of California, Santa barbara on March 24, 2017
####################################################################################################

#' Title
#'
#' @return
#' @export
#'
#' @examples
runAFAM <- function() {
  runApp("R")
}